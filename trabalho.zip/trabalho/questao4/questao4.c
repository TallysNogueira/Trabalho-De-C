#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main()
{
    char c1[50],c2[50],c3[50];
    printf("Digite a string 1:\n");
    scanf("%s",c1);
    printf("Digite a string 2:\n");
    scanf("%s",c2);
    printf("Digite a string 3:\n");
    scanf("%s",c3);

    if(isdigit(c1[0]) != 0 || isdigit(c2[0]) != 0 || isdigit(c3[0]) != 0){
        printf("Voc� digitou um n�mero, s� � permitido letras!");
        return 1;
    }


     if(strcmp(c1,c2) < 0){
        if(strcmp(c2,c3) < 0 || strcmp(c2,c3) == 0){
            printf("%s %s %s",c1,c2,c3);
        }
        else {
            if(strcmp(c1,c3) < 0 || strcmp(c1,c3) == 0) {
                printf("%s %s %s",c1,c3,c2);
            }
            else{
                printf("%s %s %s",c3,c1,c2);

            }

        }

    }

    else if(strcmp(c1,c2) > 0){
        char temp[50];
        strcpy(temp,c2);
        strcpy(c2,c1);
        strcpy(c1,temp);
        if(strcmp(c2,c3) < 0 || strcmp(c2,c3) == 0){
            printf("%s %s %s",c1,c2,c3);
        }
        else{
            if(strcmp(c1,c3) < 0 || strcmp(c1,c3) == 0) {
                printf("%s %s %s",c1,c3,c2);
            }
            else{
                printf("%s %s %s",c3,c1,c2);

            }
        }
    }

    else
    {
      if(strcmp(c1,c3) < 0){
        printf("%s %s %s",c1,c2,c3);
      }
      else{
        char temp[50];
        strcpy(temp,c1);
        strcpy(c1,c3);
        strcpy(c3,temp);
        printf("%s %s %s",c1,c2,c3);

      }
    }

    return 0;
}
