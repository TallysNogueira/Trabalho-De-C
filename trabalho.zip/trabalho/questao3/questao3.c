#include <stdio.h>
#include <time.h>

int func1(int n)
{
    if(n == 0) return 1;
    return func1(n-1) + func1(n-1);
}

int func2(int n)
{
    if(n == 0) return 1;
    return 2*func1(n-1);
}

int func3(int n)
{
    if(n == 0) return 1;
    int valor = func3(n / 2);
    if(n % 2 == 0) return valor * valor;
    else return 2 * valor * valor;
}

int main()
{
long int temp_ini,temp_final;
double temp_total;
temp_ini = clock();
func1(20);
temp_final = clock();
temp_total = ((double) temp_final - temp_ini)/CLOCKS_PER_SEC;
printf("TEMPO DE EXECUÇÃO DA FUNÇAO 1: %f\n",temp_total);

temp_ini = clock();
func2(20);
temp_final = clock();
temp_total = ((double) temp_final - temp_ini)/CLOCKS_PER_SEC;
printf("TEMPO DE EXECUÇÃO DA FUNÇAO 2: %f\n",temp_total);

temp_ini = clock();
func2(20);
temp_final = clock();
temp_total = ((double) temp_final - temp_ini)/CLOCKS_PER_SEC;
printf("TEMPO DE EXECUÇÃO DA FUNÇAO 3: %f\n",temp_total);

    return 0;
}


