
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int queryString(char *str1, char *str2);
void upperCase(char *str);

int main()
{
    char string[5000],palavra[50];
    printf("Digite um texto:\n");
    fgets(string,5000,stdin);
    printf("Digite uma palavra que deseja buscar no texto:\n");
    scanf("%s",palavra);
    upperCase(string);
    upperCase(palavra);
    queryString(string,palavra);
    return 0;
}

void upperCase(char *str){
    for(int i = 0; str[i] != '\0';i++){
        str[i] = toupper(str[i]);
    }
}


int queryString(char *str1, char *str2){
    int i,j=0,contador = 0;
    for(i = 0; i<strlen(str1);i++){
        if(str1[i] == str2[j]){
            j++;
        }
        else{
            j = 0;
        }
        if(j == strlen(str2)){
            contador++;
            j = 0;
            continue;
        }
    }
    printf("a palavra %s foi encontrada %d vezes no texto",str2,contador);

    return 0;
}