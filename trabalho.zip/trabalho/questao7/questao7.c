#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *arquivo1;
    FILE *arquivo2;
    FILE *arquivo3;
    char leitura[100];
    int valores1[5],valores2[5],valor1,valor2,soma[5];

    arquivo1 = fopen("vetor1.txt", "a");
    arquivo2 = fopen("vetor2.txt", "a");
    arquivo3 = fopen("vetor3.txt", "a");

    fclose(arquivo1);
    fclose(arquivo2);
    fclose(arquivo3);
  
    arquivo1 = fopen("vetor1.txt", "r");
    arquivo2 = fopen("vetor2.txt", "r");
    arquivo3 = fopen("vetor3.txt", "w+");


    if (arquivo1 == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        return 1;
    }
    
    if (arquivo2 == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        return 1;
    }
    
     if (arquivo3 == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        return 1;
    }

int i = 0;

    while (fgets(leitura, 100, arquivo1) != NULL) {
        valor1 = atoi(leitura);
        valores1[i] = valor1;
        printf("Valor convertido: %d\n", valor1);
        i++;
    }
    
 int j = 0;
    
        while (fgets(leitura, 100, arquivo2) != NULL) {
        valor2 = atoi(leitura);
        valores2[j] = valor2;
        printf("Valor convertido: %d\n", valor2);
        j++;
    }

for(int k=0; k < 5; k++){
    soma[k] = valores1[k] + valores2[k];
    fprintf(arquivo3,"%d\n", soma[k]);
 }
 
 
 
 
    fclose(arquivo1);
    fclose(arquivo2);
    fclose(arquivo3);




    return 0;
}
