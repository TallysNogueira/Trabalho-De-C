
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

struct Aluno{
    char nome[100];
    int matricula;
    double nota;
} aluno;


int main()
{    
    FILE *file;
    struct Aluno alunos[10];
    char *token,leitura[100];
    char string[1000] = "";
    
    file = fopen("alunos.txt", "a");
    
    if (file == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        return 1;
    }
    fclose(file);

    file = fopen("alunos.txt", "r");
    int i = 0;
    
    while(fgets(leitura,100,file) != NULL && i < 10){
        
        token = strtok(leitura,";");
        
        if(token != NULL){
           strcpy(alunos[i].nome,token);
        }
        token = strtok(NULL,";");
        
        if(token != NULL){
            alunos[i].matricula = atoi(token);
        }
        token = strtok(NULL,";");
        
        if(token != NULL){
            alunos[i].nota = atof(token);
        }
        i++;
    }

    printf("-----Tabela de alunos-----\n\n");
    for(int j=0;j < 10; j++){
        printf("Aluno %d: %s\n",j+1,alunos[j].nome);
        printf("Matrícula:%d\n",alunos[j].matricula);    
        printf("Nota:%.1f\n",alunos[j].nota);
        printf("--------------------------\n");
    }
    
    
    
    fclose(file);
    return 0;
}
