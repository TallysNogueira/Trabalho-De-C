#include <stdio.h>
#include <time.h>

int main()
{
time_t tempo;
struct tm *str_tempo;
char hora_atual[40];
time(&tempo);
str_tempo = localtime(&tempo);

strftime(hora_atual,40,"%I:%M %p",str_tempo);
printf("%s",hora_atual);

    return 0;
}