#include <stdio.h>
#include <time.h>

int main()
{
    time_t tempo;
    time(&tempo);
    struct tm *horario_atual;
    horario_atual = localtime(&tempo);

    printf("Já se passaram %d segundos",horario_atual -> tm_hour * 3600 + horario_atual->tm_min * 60 + horario_atual->tm_sec);

    return 0;
}