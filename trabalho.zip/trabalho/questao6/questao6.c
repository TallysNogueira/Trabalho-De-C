
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void upperCase(char *str);
int queryString(char *str1, char *str2);

int main()
{
    FILE *file;
    char conteudo[1000],texto[1000],palavra[50];


file = fopen("file.txt","r");
    if (file == NULL)
{
    printf("\nNão é possivel ler o arquivo!\n\n");
}

while (fgets(texto, 1000, file) != NULL) {
    strcat(conteudo,texto);
}

 printf("Digite uma palavra para procurar no arquivo:\n");
 scanf("%s",palavra);
 
 upperCase(conteudo);
 upperCase(palavra);
 queryString(conteudo,palavra);

    fclose(file);


    return 0;
}

void upperCase(char *str){
    for(int i = 0; str[i] != '\0';i++){
        str[i] = toupper(str[i]);
    }
}

int queryString(char *str1, char *str2){
    int i,j=0,contador = 0;
    for(i = 0; i<strlen(str1);i++){
        if(str1[i] == str2[j]){
            j++;
        }
        else{
            j = 0;
        }
        if(j == strlen(str2)){
            contador++;
            j = 0;
            continue;
        }
    }
    printf("a palavra %s foi encontrada %d vezes no texto",str2,contador);

    return 0;
}